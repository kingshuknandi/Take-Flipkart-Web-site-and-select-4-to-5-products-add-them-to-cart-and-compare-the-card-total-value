package Flipkart;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
public class HomePage {


		WebDriver driver = null;
		public void openBrowser() {
		// TODO Auto-generated method stub
			//System.setProperty("webdriver.chrome.driver","C:\\Users\\SASANK\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
			System.setProperty("webdriver.chrome.driver",
					System.getProperty("user.dir") + "\\Webdrivers\\chromedriver.exe");
			driver =new ChromeDriver();

		}
		public void openWebsite(){
			driver.get("https://flipkart.com/");
			driver.manage().window().maximize();

		}
		public void Login() {
			// TODO Auto-generated method stub
			//driver.findElement(By.className("_2doB4z")).click();
			driver.findElement(By.xpath("//body/div[2]/div/div/div/div/div[2]/div/form/div[1]/input")).sendKeys("9182621332");
			driver.findElement(By.xpath("//body/div[2]/div/div/div/div/div[2]/div/form/div[2]/input")).sendKeys("1234");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[4]/button")).click();
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}	
		
		public RealmePhonesPage SearchRealme() {
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			driver.findElement(By.xpath("//input[@placeholder='Search for products, brands and more']")).sendKeys("mobiles");
			driver.findElement(By.xpath("//button[@type='submit']")).click();
			
			return PageFactory.initElements(driver, RealmePhonesPage.class);
		}	
		
		

		
}
